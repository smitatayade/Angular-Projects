import { Router, RouterLinkWithHref,ActivatedRoute,convertToParamMap, ROUTES } from '@angular/router';

import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { Location } from '@angular/common';
import { RouterTestingModule } from '@angular/router/testing';
import { By } from '@angular/platform-browser';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { CreateComponent } from './create/create.component';
import { ViewComponent } from './view/view.component';
import { EditComponent } from './edit/edit.component';
import { AppComponent } from '../app.component';
import { IndexComponent } from './index/index.component';

describe('Testing routing', ()=>{
    let router:Router
    let location:Location
    let component:AppComponent
    let fixture: ComponentFixture<AppComponent>;

    beforeEach(()=>{
        TestBed.configureTestingModule({
            declarations:[ViewComponent, EditComponent, CreateComponent, IndexComponent],
            imports:[RouterTestingModule],
            providers:[]
        })
        fixture = TestBed.createComponent(AppComponent);
        component = fixture.componentInstance;

        router = TestBed.get(Router)
        location = TestBed.get(location)
        router.initialNavigation();
    });
    it('navigate to " " redirect you to index', fakeAsync(()=>{
        router.navigate([""]);
        tick();
        expect(location.path()).toBe('/index');
    }));
    it('navigate to "Blogs" redirect you to blogs', fakeAsync(()=>{
        router.navigate(["/Blogs"]);
        tick();
        expect(location.path()).toBe('/posts');
    }));
    it('navigate to "Create" redirect you to create', fakeAsync(()=>{
        router.navigate(["/create"]);
        tick();
        expect(location.path()).toBe('/create');
    }));

    it('navigate to "Edit" redirect you to Edit', fakeAsync(()=>{
        router.navigate(["/edit"]);
        tick();
        expect(location.path()).toBe('/edit');
    }));

    it('navigate to "Contact Us" redirect you to contact-Us', fakeAsync(()=>{
        router.navigate(["/contact-us"]);
        tick();
        expect(location.path()).toBe('/contact-us');
    }));
   
})


// import { APP_BASE_HREF, Location } from '@angular/common';
// import { Component, NgModule } from '@angular/core';
// import { Router, RouterModule, Routes } from '@angular/router';
// import { RouterTestingModule } from '@angular/router/testing';
// import { Shallow } from 'shallow-render';
// import { AppComponent } from '../app.component';

// @Component({
//     selector: 'go-index-link',
//     template:'<a (click)="goHome()">Go Somewhere</a>',
// })

// class IndexComponent{
//     constructor(public router:Router)
//     {}

//     async goHome(){
//         await this.router.navigate(['index']);
//     }
// }

// const routes: Routes = [{path:'index', component:class DummyComponent{}}];

// @NgModule({
//     imports:[RouterModule.forRoot(routes)],
//     providers:[{provide:APP_BASE_HREF, useValue:'/'}],
//     declarations:[AppComponent],
// })

// class PostRoutingModule {}

// describe('component with routing',()=>{
//     let shallow:Shallow<AppComponent>;

//     beforeEach(()=>{
//         shallow = new Shallow(AppComponent, PostRoutingModule).replaceModule(RouterModule, RouterTestingModule.withRoutes(routes)
//         );
//     });
//     it('use the route', async()=>{
//         const {fixture, find, inject} = await shallow.render();
//         const location = inject(Location);
//         find('a').triggerEventHandler('click', {});
//         await fixture.whenStable();
        
//     });
// });
