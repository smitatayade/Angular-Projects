import { HttpErrorResponse } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing'
import { TestBed } from '@angular/core/testing';
import { Post } from './post';
import { PostService } from './post.service';



fdescribe('PostService', () => {
  let service: PostService;
  let httpTestingController:HttpTestingController;
  let url='https://localhost:4200';
  
  beforeEach(() => {
    TestBed.configureTestingModule({

      imports:[HttpClientTestingModule],
      providers:[PostService]
   
  });
  service = TestBed.inject(PostService);
  httpTestingController= TestBed.inject(HttpTestingController);
});
  
afterEach(()=>{
  httpTestingController.verify()
})

it('should create service', ()=>{
  expect(service).toBeTruthy();
})

  it('should test HttpClient.get to get data',()=>{
    const testingPost: Post[] = [
      {id:1, title:'testing title 1', image:'www.img.jpg', description:'tesing body 1'},
      {id:2, title:'testing title 2', image:'www.img1.jpg' ,description:'tesing body 2'}];

    service.getAll().subscribe((posts) =>{

      expect(testingPost).toBe(posts, 'should check dummy data');
    
  });
  const reque=httpTestingController.expectOne(service.apiURL+'/posts/');

  expect(reque.cancelled).toBeFalsy();
  expect(reque.request.responseType).toEqual('json');
  reque.flush(testingPost);
 });
 
 it('should add Blog and return added Blog', ()=>{
   const newpost: Post={id:101, title:'new post', image:'www.img1.jpg', description:'sample text'};

   service.create(newpost).subscribe((create)=>{
     expect(create).toBe(newpost);
   });
   const reque = httpTestingController.expectOne(service.apiURL+'/posts/');

   expect(reque.cancelled).toBeFalsy();
   expect(reque.request.responseType).toEqual('json');

   reque.flush(newpost);
 });

 it('should get single data',()=>{
  const getpost:Post={ id: 2, title: 'Sample single Title ', image:'www.img1.jpg', description:'Sample single body text'};
   
  service.find(getpost.id).subscribe(find=>{
   expect(find).toBe(getpost)
 });
  
 const reque=httpTestingController.expectOne(service.apiURL+'/posts/'+getpost.id);
   expect(reque.cancelled).toBeFalsy();
   expect(reque.request.responseType).toEqual('json');
   reque.flush(getpost)
});

it('should delete single data', ()=>{
  const dltpost:Post={ id:3, title:'sample deleted title', image:'www.img1.jpg', description:'sample deleted body' };
  service.delete(dltpost.id).subscribe(deletelist=>{
    expect(deletelist).toBe(dltpost)
  });
  const reque=httpTestingController.expectOne(service.apiURL+'/posts/'+dltpost.id)
  expect(reque.cancelled).toBeFalsy();
  expect(reque.request.responseType).toEqual('json');
  reque.flush(dltpost)
});


});
