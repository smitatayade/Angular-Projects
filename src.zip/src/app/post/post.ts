export class Post {
    id: number;
    title: string;
    description: string;
    image:any;
}
