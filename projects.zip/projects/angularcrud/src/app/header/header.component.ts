import { Component, OnInit } from '@angular/core';
import { timer } from 'rxjs';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor() { }
datetime: Date
now :any
timevalue=""

  ngOnInit(): void {
    // this.datetime = new Date()
this.now = new Date().getHours()
    timer(0, 1000).subscribe(()=>{
      this.datetime = new Date
    })
    if(this.now>=0 && this.now<=12){
      this.timevalue="Good Morning!"
    }
    else if(this.now>=13 && this.now<=16){
      this.timevalue="Good Afternoon!"
    
    }
    else if (this.now>=17 && this.now<=23){
      this.timevalue="Good Evening!"
      
    }
  }
  

}
