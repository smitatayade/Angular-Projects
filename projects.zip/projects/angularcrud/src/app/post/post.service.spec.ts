import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing'
import { TestBed } from '@angular/core/testing';
import { Post } from './post';
import { PostService } from './post.service';



describe('PostService', () => {
  let service: PostService,
  httpTestingController:HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    imports:[HttpClientTestingModule]
    providers:[PostService]
  });
  beforeEach(()=>{
    service = TestBed.get(PostService);
    httpTestingController= TestBed.get(HttpTestingController);

  });

  

  it('should test HttpClient.get', () => {
    const testingPost:Post[] = [
      {id:1, title:'testing title 1', image:'www.image1.jpd',body:'tesing body 1'},
      {id:2, title:'testing title 2', image:'www.image.jpg', body:'testing body 2'}
    ];
    service.getAll().subscribe(posts)=>{
      expect(testingPost).toBe(posts, 'should check dummy data');
    
  });
  const reque=httpTestingController.expectOne(service.apiURL+'posts');

  expect(reque.cancelled).toBeFalsy();
  expect(reque.request.responseType).toEqual('json');
  reque.flush(testingPost);
});
