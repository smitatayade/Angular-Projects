import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-netflixhome',
  templateUrl: './netflixhome.component.html',
  styleUrls: ['./netflixhome.component.css']
})
export class NetflixhomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
