import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fordemo',
  templateUrl: './fordemo.component.html',
  styleUrls: ['./fordemo.component.css']
})
export class FordemoComponent{
    navItems = [
      {Category: 'Electronics', Products: ['JBL Speaker', 'Earpods']},
      {Category: 'Footwear', Products: ['Nike Casuals', 'Lee Cooper Boot']},
      {Category: 'Fashion', Products: ['Shirt', 'Jeans']}
    ];
}
