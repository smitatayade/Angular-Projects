import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-switchdemo',
  templateUrl: './switchdemo.component.html',
  styleUrls: ['./switchdemo.component.css']
})
export class SwitchdemoComponent{
  product = {
    Name: 'Nike Casuals',
    Price: 4600.66,
    InStock: true,
    Photo: 'assets/shoe.jpg',
    Description: 'something about nike casuals'
  };
  selectedView = 'details';
  Show(e){
     this.selectedView = e.target.name;
  }

}
