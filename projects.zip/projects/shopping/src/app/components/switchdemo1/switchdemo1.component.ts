import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-switchdemo1',
  templateUrl: './switchdemo1.component.html',
  styleUrls: ['./switchdemo1.component.css']
})
export class Switchdemo1Component{
  product = {
    Name: 'Nike Casuals',
    Price: 4600.66,
    InStock: true,
    Photo: 'assets/Shoe.PNG',
    Description: 'something about nike casuals'
  };
  selectedView = 'details';
  views = ['details', 'preview', 'description'];
  count = 0;
  Show(e){
     this.selectedView = e.target.name;
  }
  NextClick() {
    this.count ++;
    this.selectedView = this.views[this.count];
    if(this.count == this.views.length) {
      this.selectedView = this.views[0];
    }
  }
  PreviousClick(){
    this.count --;
    this.selectedView = this.views[this.count];
  }

}
