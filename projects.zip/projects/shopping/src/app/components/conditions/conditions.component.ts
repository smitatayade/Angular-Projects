import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-conditions',
  templateUrl: './conditions.component.html',
  styleUrls: ['./conditions.component.css']
})
export class ConditionsComponent{
  products = [
    {Name: 'Earpods', Price: 4500.44, Photo: 'assets/Earpods.PNG', Category: 'Electronics'},
    {Name: 'JBL Speaker', Price: 6500.44, Photo: 'assets/Speaker.PNG', Category: 'Electronics'},
    {Name: 'Nike Casuals', Price: 5500.44, Photo: 'assets/Shoe1.PNG', Category: 'Footwear'},
    {Name: 'Lee Boot', Price: 2500.44, Photo: 'assets/Shoe1.PNG', Category: 'Footwear'},
    {Name: 'Shirt', Price: 1500.44, Photo: 'assets/Shirt.PNG', Category: 'Fashion'},
    {Name: 'Jeans', Price: 3500.44, Photo: 'assets/Shirt.PNG', Category: 'Fashion'}
  ];
  categories = ['All', 'Electronics', 'Footwear', 'Fashion'];
  selectedCategory = 'All';
}
