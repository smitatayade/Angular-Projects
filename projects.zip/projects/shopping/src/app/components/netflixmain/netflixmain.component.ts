import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-netflixmain',
  templateUrl: './netflixmain.component.html',
  styleUrls: ['./netflixmain.component.css']
})
export class NetflixmainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
