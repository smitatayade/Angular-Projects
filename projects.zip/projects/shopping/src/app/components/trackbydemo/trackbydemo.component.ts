import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trackbydemo',
  templateUrl: './trackbydemo.component.html',
  styleUrls: ['./trackbydemo.component.css']
})
export class TrackbydemoComponent {
  products = [
    {Id: 1, Name: 'TV', Price: 34000.49},
    {Id: 2, Name: 'Mobile', Price: 23000.44}
  ];
  AddNewProduct(){
    this.products = [
      {Id: 1, Name: 'TV', Price: 34000.49},
      {Id: 2, Name: 'Mobile', Price: 23000.44},
      {Id: 3, Name: 'Shoe', Price: 4500.44}
    ];
  }
  TrackChange(index) {
     return index;
  }

}
