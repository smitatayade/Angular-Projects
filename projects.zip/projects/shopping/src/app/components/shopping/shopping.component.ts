import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shopping',
  templateUrl: './shopping.component.html',
  styleUrls: ['./shopping.component.css']
})
export class ShoppingComponent implements OnInit{ 
  categories:string[]|null=null;
  product:any[]|null=null;
  constructor(){ }

  GetAllCategories(){
    fetch('http://fakestoreapi.com/products/categories')
    .then(response=> response.json())
    .then(data => {
    data.unshift('All');
      this.categories = data;
    })
  }

  GetAllProducts(){
    fetch('http://fakestoreapi.com/products')
    .then(response=> response.json())
    .then(data=> {
      this.product = data;
    })
  }

  ngOnInit(): void {
   this.GetAllCategories();
   this.GetAllProducts();
  }

  CategoryChanged(e:any){
    if(e.target.value=='All'){
      this.GetAllProducts();
    }else{
      fetch(`http://fakestoreapi.com/products/category/$(e.target.value)`)
      .then(response=>response.json())
      .then(data=>{
        this.product=data;
      })
    }
  }
  searchedProduct:any|null={};
  cartItems:any|null=[];
  count:number|undefined=0;
  AddToCartclick(id:any){
    fetch(`http://fakestoreapi.com/products/${id}`)
    .then(response=>response.json())
    .then(data=>{
      this.searchedProduct=data;
      this.cartItems?.push(this.searchedProduct);
      this.count=this.cartItems?.length;
    })
    alert('Item Added To Cart');
  }
  isCartVisible=false;
  ToggleCart(){
    this.isCartVisible=(this.isCartVisible==false)?true:false;
  }
  RemoveClick(index:any){
    let flag=confirm('Are You Sure? Want to delete?');
    if(flag==true){
      this.cartItems?.splice(index,1);
      this.count=this.cartItems?.length;
    }
  }
}
