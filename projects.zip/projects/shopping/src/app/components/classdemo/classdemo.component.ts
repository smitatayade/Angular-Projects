export class ClassdemoComponent{
  className = 'effects';
}
