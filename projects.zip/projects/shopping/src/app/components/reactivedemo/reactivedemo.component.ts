import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators,FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-reactivedemo',
  templateUrl: './reactivedemo.component.html',
  styleUrls: ['./reactivedemo.component.css']
})
export class ReactivedemoComponent implements OnInit {

  constructor(private fb:FormBuilder) { }

  ngOnInit(): void {
  }
frmRegister = new FormGroup({
  Name: new FormControl('',[Validators.required, Validators.minLength(4)]),
  Price: new FormControl('',[Validators.required]),
  frmStockDetails: new FormGroup({
    stock:new FormControl(''),
    City:new FormControl('')
  })
})
RegisterClick(obj:any){
  alert(JSON.stringify(obj));
}
frrmRegister=this.fb.group({
  name:['',[Validators.required, Validators.minLength(4)]],
  price:['',[Validators.required]],
  frrmStockDetails:this.fb.group({
    city:[''],
    stock:['']
  })
})
submitted=false;
registerclick(obj:any){
  this.sub(property) ReactivedemoComponent.frrmRegister:FormGroup
  if(this.frrmRegister.invalid){
    return;
  }
  alert(JSON.stringify(obj));
}
}
