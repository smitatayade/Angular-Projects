import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipedemo',
  templateUrl: './pipedemo.component.html',
  styleUrls: ['./pipedemo.component.css']
})
export class PipedemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  product:any={
    Name:'Samsung TV',
    Price:57000.60,
    Mfd:new Date('2021-01-11'),
    Sales:0.29
  }
  products1:string[]=["Tv","Mobile","Shoe","Shirt","Jeans"];
  shoppingCart=[
    {Name:'JBL Speaker', City:'Delhi'},
    {Name:'Nike Casuals', City:'hyd'},
    {Name:'Shirts', City:'Delhi'},
    {Name:'Jeans', City:'Chennai'}
  ];
  deliveryStatus={
    'Delhi':'Delivery in 2 Days',
    'hyd':'Same day delivery',
    'Chennai':'One day delivery',
    'other':'Unknown - we will update soon'
  };
 notifications:any[]=[];
 statusMessage = {
   '=0':'No New Notifications',
   '=1':'One New Notification',
   'other':'#New Notification'
 }
 CallClick(){
   this.notifications.push('Call From Manager');
 }
 GameClick(){
   this.notifications.push('New Game Installed');
 }
 UpdateClick(){
   this.notifications.push('Facebook Updated');
 }
 title = "welcOME TO Angular";
 cities = ["Chennai","Delhi","Mumbai","Goa","Banglore","Hyd"]
}
