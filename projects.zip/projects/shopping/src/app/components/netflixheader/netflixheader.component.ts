import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-netflixheader',
  templateUrl: './netflixheader.component.html',
  styleUrls: ['./netflixheader.component.css']
})
export class NetflixheaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
