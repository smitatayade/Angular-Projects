import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-databinding',
  templateUrl: './databinding.component.html',
  styleUrls: ['./databinding.component.css']
})
export class DatabindingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  
  product:any={
    Name: 'Nike Casuals',
    Price: 56000.44,
    Photo: 'assets/Shoe1.PNG'
  }
  disableButton:boolean=false;

  tableWidth=400;
  tableHeight=100;

  RegisterClick(){
    alert('Registered!')
  }
}
