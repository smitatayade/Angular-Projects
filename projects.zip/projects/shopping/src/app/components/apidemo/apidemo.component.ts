import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-apidemo',
  templateUrl: './apidemo.component.html',
  styleUrls: ['./apidemo.component.css']
})
export class ApidemoComponent implements OnInit {

  constructor(private data:DataService) { }

  categories:any[]=[];
  products:any[]=[];

  ngOnInit(): void {
    this.data.GetCategories().subscribe(category=>this.categories=category);
    this.data.GetProducts().subscribe(product=>this.products=product);
  }

}
