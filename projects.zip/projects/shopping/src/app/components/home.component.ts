import { Component } from "@angular/core";

@Component({
    selector: 'app-home',
    template: `
    <div class="container-fluid mt-3 p-4">
        <h2 class="p-3">{{title}}</h2>
        <p>Online Shopping Store</p>
    </div>
    `,
    styles:['h2{background-color:red; color:white; text-align:center}','p{text-align:center; color:blue}']
})
export class HomeComponent 
{
    title:string = 'Shopping -Home';
}