import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-styledemo',
  templateUrl: './styledemo.component.html',
  styleUrls: ['./styledemo.component.css']
})
export class StyledemoComponent{
  styleObject = {
    'position': 'fixed',
    'top': '',
    'left': ''
  };
  onMouseMove(e) {
     this.styleObject = {
       'position': 'fixed',
       'top': e.clientY + 'px',
       'left': e.clientX + 'px'
     };
  }
}
