import { Component, IterableDiffer, OnInit } from '@angular/core';

@Component({
  selector: 'app-likedemo',
  templateUrl: './likedemo.component.html',
  styleUrls: ['./likedemo.component.css']
})
export class LikedemoComponent{

  products = [
    {Name: 'JBL Speaker', Photo: 'assets/Speaker.PNG', Likes: 0, Dislikes: 0},
    {Name: 'Nike Casuals', Photo: 'assets/Shoe1.PNG', Likes: 0, Dislikes: 0},
    {Name: 'Shirt', Photo: 'assets/Shirt.PNG', Likes: 0, Dislikes: 0},
  ];
  onLikesClick(item){
     item.Likes++;
  }
  onDislikesClick(item){
     item.Dislikes++;
  }


}
