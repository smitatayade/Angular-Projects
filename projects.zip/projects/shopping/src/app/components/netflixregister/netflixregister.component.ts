import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-netflixregister',
  templateUrl: './netflixregister.component.html',
  styleUrls: ['./netflixregister.component.css']
})
export class NetflixregisterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
