import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AdminComponent } from "./components/admin/admin.component";
import { CategoriesComponent } from './components/categories/categories.component';
import { DetailsComponent } from "./components/details/details.component";
import { ErrorComponent } from "./components/error/error.component";
import { HomeComponent } from "./components/home/home.component";
import { LoginComponent } from "./components/login/login.component";
import { NotfoundComponent } from './components/notfound/notfound.component';
import { ProductsComponent } from './components/products/products.component';
import { AdminGuard } from "./guards/admin.guard";

const routes: Routes = [
    {path: 'home', component : HomeComponent},
    {path: 'categories', component : CategoriesComponent},
    {path: 'categories/:category', component : ProductsComponent, children:[
        {path:'details/:id', component:DetailsComponent}
    ]},
    
    {path:'login', component:LoginComponent},
    {path:'error',component:ErrorComponent},
    {path: ' ', redirectTo: 'home', pathMatch: 'full'},
    {path:'admin', component:AdminComponent, canActivate: [AdminGuard]},
    {path: '**', component:NotfoundComponent}
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }








