import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataService } from 'projects/shopping/src/app/components/data.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  products:any[]=[];
  filteredProducts:any[]=[];
  category:any;
  constructor(private data : DataService, private route:ActivatedRoute) { }

  ngOnInit(): void {
    this.category=this.route.snapshot.paramMap.get('category');
    this.data.GetProducts().subscribe(product =>{
      this.products=product;
      this.filteredProducts=this.products.filter(product=> product.category==this.category);
    })
  }

}
