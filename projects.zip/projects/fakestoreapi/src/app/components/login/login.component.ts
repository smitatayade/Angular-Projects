import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router:Router ) { }

  ngOnInit(): void {
  }
  LoginClick(obj:any){
    if(obj.UserName=='john_nit' && obj.Password=='admin'){
      this.router.navigate(['categories']);
    }else{
      this.router.navigate(['error']);
    }
  }
}
