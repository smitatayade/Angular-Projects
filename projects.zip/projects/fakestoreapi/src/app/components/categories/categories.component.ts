import { Component, OnInit } from '@angular/core';
import { DataService } from 'projects/shopping/src/app/components/data.service';

@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.css']
})
export class CategoriesComponent implements OnInit {

  categories:any[]=[];
  constructor(private data: DataService) { }

  ngOnInit(): void {
    this.data.GetCategories().subscribe(category=> this.categories=category);
  }

}
