import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataService } from 'projects/shopping/src/app/components/data.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
  ProductId:any;
  Products:any[]=[];
  searchedProduct:any={};
  constructor(private data: DataService, private route:ActivatedRoute) { }

  ngOnInit(): void {
    this.ProductId=this.route.snapshot.paramMap.get('id');
    this.data.GetProducts().subscribe(product=>{
      this.Products=product;
      this.searchedProduct=this.Products.find(product=>product.id==this.ProductId);
    })
  }

}
