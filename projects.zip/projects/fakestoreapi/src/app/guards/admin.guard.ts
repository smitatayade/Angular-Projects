import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminGuard implements CanActivate {
  UserName='john_nit';
  Password='john11';
  constructor(private router:Router){

}

  canActivate():boolean{
    if(this.UserName=='john_nit' && this.Password=='john11'){
      return true;
    }
    else{
     this.router.navigate(['login']);
     return false;
    }
  }
  
}
