import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminregisterComponent } from './components/adminregister/adminregister.component';
import { AdminloginComponent } from './components/adminlogin/adminlogin.component';
import { IshophomeComponent } from './components/ishophome/ishophome.component';
import { InvalidloginComponent } from './components/invalidlogin/invalidlogin.component';
import { CategorieslistComponent } from './components/categorieslist/categorieslist.component';

@NgModule({
  declarations: [
    AppComponent,
    AdminregisterComponent,
    AdminloginComponent,
    IshophomeComponent,
    InvalidloginComponent,
    CategorieslistComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
