import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminloginComponent } from './components/adminlogin/adminlogin.component';
import { AdminregisterComponent } from './components/adminregister/adminregister.component';
import { InvalidloginComponent } from './components/invalidlogin/invalidlogin.component';
import { IshophomeComponent } from './components/ishophome/ishophome.component';

const routes: Routes = [
  {path: 'adminregister', component:AdminregisterComponent},
 {path: 'adminlogin', component:AdminloginComponent},
 {path: 'ishophome', component:IshophomeComponent},
 {path: 'invalidlogin', component:InvalidloginComponent}, 
 {path: '', redirectTo:'ishophome', pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
