export interface IAdmin
{
    UserId:string;
    FirstName:string;
    LastName:string;
    Password:string;
}