import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IAdmin } from '../contracts/IAdmin';

@Injectable({
  providedIn: 'root'
})
export class IshopapiService {

  constructor(private http:HttpClient) { }
  
  GetAdmin():Observable<IAdmin[]>{
    return this.http.get<IAdmin[]>('http://127.0.0.1:8080/getadmin');

  }

  RegisterAdmin(data:IAdmin):Observable<IAdmin>{
    return this.http.post<IAdmin>('http://127.0.0.1:8080/adminregister', data);
  }

  GetProducts():Observable<any[]>{
    return this.http.get<any[]>('http://127.0.0.1:8080/products');
  }

  GetCategories():Observable<any[]>{
    return this.http.get<any[]>('http://127.0.0.1:8080/categories');
  }
}






