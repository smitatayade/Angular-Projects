import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invalidlogin',
  templateUrl: './invalidlogin.component.html',
  styleUrls: ['./invalidlogin.component.css']
})
export class InvalidloginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
