import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { IshopapiService } from '../../services/ishopapi.service';

@Component({
  selector: 'app-categorieslist',
  templateUrl: './categorieslist.component.html',
  styleUrls: ['./categorieslist.component.css']
})
export class CategorieslistComponent implements OnInit {

  constructor(private ishopapi:IshopapiService) { }

  categories:any[]=[];
  @Input() electronicsCount=0;
  @Input() jeweleryCount=0;
  @Input() mensCount=0;
  @Input() womensCount=0;

  @Output()CategoryChanged:EventEmitter<string> = new EventEmitter<string>();
  ngOnInit(): void {
    this.ishopapi.GetCategories().subscribe(data=>this.categories=data);
  }
  CategoryClick(e:any){
    this.CategoryChanged.emit(e.target.name);
  }
}
