import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IshopapiService } from '../../services/ishopapi.service';

@Component({
  selector: 'app-adminregister',
  templateUrl: './adminregister.component.html',
  styleUrls: ['./adminregister.component.css']
})
export class AdminregisterComponent implements OnInit {

  constructor(private ishopapi: IshopapiService, private router:Router) { }

  ngOnInit(): void {
  }
  RegisterClick(data:any){
    this.ishopapi.RegisterAdmin(data).subscribe();
    alert('Registered Successfully');
    this.router.navigate(['adminlogin']);
  }
}
