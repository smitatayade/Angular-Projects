import { Component, OnInit } from '@angular/core';
import { IshopapiService } from '../../services/ishopapi.service';

@Component({
  selector: 'app-ishophome',
  templateUrl: './ishophome.component.html',
  styleUrls: ['./ishophome.component.css']
})
export class IshophomeComponent implements OnInit {

  constructor(private ishopapi:IshopapiService) { }

  products:any[]=[];
  electronicsCount=0;
  jeweleryCount=0;
  mensCount=0;
  womensCount=0;
  selectedCategory='';

  ngOnInit(): void {
    this.ishopapi.GetProducts().subscribe(data=>{
      this.products=data;
      this.electronicsCount=this.products.filter(product=>product.category=='electronics').length;
      this.jeweleryCount=this.products.filter(product=>product.category=='jewelery').length;
      this.mensCount=this.products.filter(product=>product.category=="men's clothing").length;
      this.womensCount=this.products.filter(product=>product.category=="women's clothing").length;
    });
   
    
  }
  CategoryChanged(e:any){
    this.selectedCategory = e;
  }
}
