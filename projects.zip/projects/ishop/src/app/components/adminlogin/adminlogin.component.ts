import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IshopapiService } from '../../services/ishopapi.service';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {

  constructor(private ishopapi:IshopapiService, private router:Router) { }

  adminUsers:any[]=[];
  ngOnInit(): void {

    this.ishopapi.GetAdmin().subscribe(data=>this.adminUsers=data);
  }
  LoginClick(data:any){
   for(var user of this.adminUsers){
     if(user.UserId==data.UserId && user.Password==data.Password){
       this.router.navigate(['ishophome']);
       break;
     }else{
       this.router.navigate(['invalidlogin']);
     }
   }
  }
}
