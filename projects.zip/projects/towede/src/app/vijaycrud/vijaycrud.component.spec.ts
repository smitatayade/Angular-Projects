import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VijaycrudComponent } from './vijaycrud.component';

describe('VijaycrudComponent', () => {
  let component: VijaycrudComponent;
  let fixture: ComponentFixture<VijaycrudComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VijaycrudComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VijaycrudComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
