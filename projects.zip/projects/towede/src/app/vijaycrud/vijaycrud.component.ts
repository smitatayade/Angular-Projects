import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vijaycrud',
  templateUrl: './vijaycrud.component.html',
  styleUrls: ['./vijaycrud.component.css']
})
export class VijaycrudComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
