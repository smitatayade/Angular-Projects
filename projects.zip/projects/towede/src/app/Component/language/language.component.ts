import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-language',
  templateUrl: './language.component.html',
  styleUrls: ['./language.component.css']
})
export class LanguageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  showmodal=true;
  showmodal1(){
    this.showmodal=false;
  }
}
