import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-password',
  templateUrl: './password.component.html',
  styleUrls: ['./password.component.css']
})
export class PasswordComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  title:string = 'Change Password';
  showModal:any;
  showModalregister:any;
  showModalpassword:any;
  showModal1(){
    this.showModal=false;
  }
  showModalpassword1(){
    this.showModalpassword=false;
  }
  showModalregister1(){
    this.showModalregister=false;
  }
}

