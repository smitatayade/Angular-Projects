import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offer',
  templateUrl: './offer.component.html',
  styleUrls: ['./offer.component.css']
})
export class OfferComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
   countDownDate=new Date("December 16, 2021 13:54:00").getTime();
  //  demo:any;
   Day:any;
   Hours:any;
  Minute:any;
  Seconds:any;
  x = setInterval(()=>{
    var now=new Date().getTime();
    var distance = this.countDownDate-now;
    var days = Math.floor(distance/(1000*60*60*24));
    var hours= Math.floor((distance%(1000*60*60*24))/(1000*60*60));
    var minutes=Math.floor((distance%(1000*60*60))/(1000*60));
    var seconds=Math.floor((distance%(1000*60))/1000);
    // this.demo=days  + "d" + hours + "h" + minutes + "m" + seconds + "s";
    this.Day=days;
    this.Hours=hours;
    this.Minute=minutes;
    this.Seconds=seconds;
  
    if(days<=0 && hours<=0 && minutes<=0 && seconds<=0){
      // clearInterval(this.x);
      // this.demo="Expired";
      clearInterval(this.x);
      this.Day="expired";
      this.Hours="expired";
      this.Minute="expired";
      this.Seconds="expired";
    }
  })
  }
