import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { HeaderComponent } from './Component/header/header.component';
import { FooterComponent } from './Component/footer/footer.component';
import { PasswordComponent } from './Component/password/password.component';
import { IndexComponent } from './Component/index/index.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ReviewComponent } from './Component/review/review.component';
import { StepsComponent } from './Component/steps/steps.component';
import { CarouselComponent } from './Component/carousel/carousel.component';
import { FormsModule } from '@angular/forms';
import { LanguageComponent } from './Component/language/language.component';
import { PackagesComponent } from './Component/packages/packages.component';
import { NotFoundComponent } from './Component/not-found/not-found.component';
import { OfferComponent } from './Component/offer/offer.component';
import { ChooseusComponent } from './Component/chooseus/chooseus.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { VijaycrudComponent } from './vijaycrud/vijaycrud.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    PasswordComponent,
    IndexComponent,
    ReviewComponent,
    StepsComponent,
    CarouselComponent,
    LanguageComponent,
    PackagesComponent,
    NotFoundComponent,
    OfferComponent,
    ChooseusComponent,
    VijaycrudComponent,
  
    
  ],
  imports: [
    BrowserModule,
    NgbModule,
    FormsModule,
    AppRoutingModule,
    RouterModule,
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [LanguageComponent]
})
export class AppModule { }
